import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.InputMismatchException;
import java.util.Scanner;

public class StudentList 
{
	private Scanner s = new Scanner(System.in);

	// for DB
	private Connection con = null ;
	private Statement st = null;
	private ResultSet rs = null;
	private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	    
	public StudentList()
	{
		 try
		 {
				Class.forName("com.mysql.jdbc.Driver"); 
	            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentlist", "root", "1492");
	            st = con.createStatement();
	            
	            System.out.println("��񿬰��");       
	     }
		 
		 catch (SQLException se) { System.out.println("��񿬰�ȵ�"); } 
		 catch (ClassNotFoundException e) { e.printStackTrace(); }
	}
	
	public void insertStudent() 
	{
		
		
		int i_id = 0;
		String i_name = "";
		String i_department = "";
		int i_grade = 0;
		String i_phone_no = "";
		
		
		try
		{
			System.out.println("���ο� �л��� �߰��մϴ�. �л������� �Է��Ͻʽÿ�.");
			System.out.print("�й� : ");
			i_id = s.nextInt();
			
			System.out.print("�̸� : ");
			i_name = s.next();
			
			System.out.print("�а� : ");
			i_department = s.next();
			
			System.out.print("�г� : ");
			i_grade = s.nextInt();
			
			System.out.print("����ó : ");
			i_phone_no = s.next();
			
			String sql = "insert into studentlist values(" + i_id + "," + "'" + i_name + "'" + "," + "'" + i_department + "'" + "," + i_grade +"," + "'" + i_phone_no + "');";
			st.executeUpdate(sql);
			
	        System.out.println("�Է� �Ϸ�");
		}
	
		
		catch (InputMismatchException e) {System.out.println( "�й� �� �г��� ���ڷ� �Է��Ͻʽÿ�. "); }
		catch (SQLException e) { e.printStackTrace(); }
		catch (NumberFormatException ne) {System.out.println(ne.getMessage()); }
        
	}
	
	public void deleteStudent()
	{
		int deleteId;
		System.out.println("������ �й��� �Է��Ͻʽÿ�.");
		System.out.print("�й� : ");
		
		deleteId = s.nextInt();
		
		if( findStudent(deleteId) == true )
		{
			try
			{
				String sql = "delete from studentlist where id = " + deleteId;
				
				st.executeUpdate(sql);
				System.out.println(deleteId + "�� �����Ǿ����ϴ�.");
				
			}
			
			catch (SQLException e) { e.printStackTrace(); }
			catch (NumberFormatException e1) { e1.printStackTrace(); }
		}
		
		else
			System.out.println("ã�� ID�� �����ϴ�.");	
	}
	
	
	public void updateStudent()
	{
		int updateId;
		System.out.println("������ �й��� �Է��Ͻʽÿ�.");
		System.out.print("�й� : ");
		updateId = s.nextInt();
				
		if( findStudent(updateId) == true )
		{
			try
			{
				System.out.println(updateId + "�й��� �л������� �����մϴ�." + "�л������� �Է��Ͻʽÿ�.");
				System.out.print("�й� : ");
				int r_id = s.nextInt();
				System.out.print("�̸� : ");
				String r_name = s.next();
				System.out.print("�а� : ");
				String r_department = s.next();
				System.out.print("�г� : ");
				int r_grade = s.nextInt();
				System.out.print("����ó : ");
				String r_phone_no = s.next();
					
				String qurry = "update studentlist set id = " + r_id + ", name = '" + r_name + "', department = '" + r_department + "', grade = " + r_grade + ", phone_no = '" + r_phone_no + 
						"' where id = " + updateId;
			    st.executeUpdate(qurry);
			    System.out.println(updateId + "�й��� ������ �����Ǿ����ϴ�.");
			}
			catch (SQLException e) { e.printStackTrace(); }
		}
		
		else
			System.out.println("ã�� ID�� �����ϴ�.");	
	}
	
	public void printStudnet()
	{
		try 
		{
			// ����Ҷ� ������������ �����.
			String sql1 = "select * from studentlist order by id";
        
			rs = st.executeQuery(sql1);
		
			System.out.println("<< �л� ���� >>");
			while(rs.next()) 
			{
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String department = rs.getString("department");
				int grade = rs.getShort("grade");
				String phone_no = rs.getString("phone_no");
				
				System.out.println("Id : " + id);
				System.out.println("Name : " + name);
				System.out.println("Department : " + department);
				System.out.println("grade : " + grade);
				System.out.println("phone_no : " + phone_no);
				System.out.println();

			}
        
		} 
        catch (SQLException e) { e.printStackTrace(); }
	}
	
	public boolean findStudent(int findID)
	{
		try
		{
			String qurry = "select * from studentlist where id = " + findID ;
			
			rs = st.executeQuery(qurry);
			
			if( rs.next() )
				return true;	
		} 
		
		catch (SQLException e) { e.printStackTrace(); }
		catch (NumberFormatException e) {e.printStackTrace();} 
		
		return false;	
	}
}
