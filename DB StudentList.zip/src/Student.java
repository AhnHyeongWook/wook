public class Student 
{
	
	private int id;
	private String name;
	private String department;
	private int grade;
	private String phone_no;
	
	//public Student() { }
	public Student(int id, String name, String department, int grade, String phone_no) 
	{
		this.id = id;
		this.name = name;
		this.department = department;
		this.grade = grade;
		this.phone_no = phone_no;
	}
	
	public void setId(int id) { this.id = id; }
	public void setName(String name) { this.name = name; }
	public void setDepartment(String department) { this.department = department; }
	public void setGrade(int grade) { this.grade = grade; }
	public void setPhone_no(String phone_no) { this.phone_no = phone_no; }
	
	public int getId() { return id; }
	public String getName() { return name; }
	public String getDepartment() { return department; }
	public int getGrade() { return grade; }
	public String getPhone_no() { return phone_no; }
	

}
