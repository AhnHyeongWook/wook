import java.awt.BorderLayout;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class CurrentClock extends JPanel implements Runnable{
	private int i = Calendar.getInstance().get(Calendar.AM_PM);
	private String[] ampm = {"AM", "PM"};
	private SimpleDateFormat clock = new SimpleDateFormat("hh:mm:ss");
	private String time = clock.format(new Date());
	private JLabel timeLabel, ampmLabel;
	private JLabel lblNewLabel_1;
	private Calendar today;
	private Calendar cal;
	private int year, month, day = 0;
	private JLabel lblNewLabel;
	
	public CurrentClock() {
		timeLabel = new JLabel(time);
		timeLabel.setBounds(0, 0, 100, 20);
		timeLabel.setForeground(Color.BLACK);
		
		ampmLabel = new JLabel(ampm[i]);
		ampmLabel.setBounds(15, 20, 100, 30);
		ampmLabel.setForeground(new Color(36, 205, 198));
		
		
		today = Calendar.getInstance(); // 디폴트의 타임 존 및 로케일을 사용해 달력을 가져옵니다.
		cal = new GregorianCalendar();
		year = today.get(Calendar.YEAR);
		month = today.get(Calendar.MONTH) + 1;// 1월의 값이 0
		day = today.get(Calendar.DATE);
		
		lblNewLabel = new JLabel("                                                                                                                                                                                                                                                                                                              ");
		add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel(year + "-" + month + "-" + day + " ");
		add(lblNewLabel_1);
		
		add(timeLabel, BorderLayout.NORTH);
		add(ampmLabel, BorderLayout.CENTER);
	}
	
	
	@Override
	public void run() {
		
		do {
			try 
			{
				Thread.sleep(1000);
				time = clock.format(new Date());
				timeLabel.setText(time);
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		} while (true);
	}	
}	
