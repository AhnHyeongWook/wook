import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.rmi.CORBA.Tie;
import javax.security.sasl.RealmCallback;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ListSelectionListener;

import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class ScheduleManageFrame extends JFrame implements ActionListener{

	private JPanel panel;
	private JList list = new JList(new DefaultListModel());
	private DefaultListModel model;
	private JLabel scheduleDateLabel;
	private JButton btnDelete;
	private JButton btnRevise;
	private ArrayList<String> tempContents = new ArrayList<String>(); 
	private ArrayList<String> tempAllDate = new ArrayList<String>();
	private ArrayList<String> tempAllTime = new ArrayList<String>();
	private ArrayList<String> tempAllSchedule = new ArrayList<String>();
	private String date, time, schedule, reDate, reTime, reSchedule;
	private int select, index;
	private String clickYear, clickMonth;
	private CalenderFrame cf;



	public ScheduleManageFrame( CalenderFrame cf) {
		init();
		run();
		this.cf = cf;

		
	}
	
	public void init()
	{
		
		// frame
		setBounds(600, 400, 453, 387);
		list.addMouseListener(new MouseAdapter() 
		{
			public void mouseClicked(MouseEvent e) 
			{
				btnRevise.setEnabled(true);
				btnDelete.setEnabled(true);
			}
		});
		list.setFont(new Font("굴림", Font.PLAIN, 22));
		list.setBackground(Color.LIGHT_GRAY);
		

		// panel
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setLayout(null);
		
		
		// list
		list.setBounds(14, 55, 407, 231);
		model = (DefaultListModel) list.getModel();
		
		
		// label
		scheduleDateLabel = new JLabel();
		scheduleDateLabel.setFont(new Font("Vijaya", Font.PLAIN, 30));
		scheduleDateLabel.setForeground(Color.BLACK);
		scheduleDateLabel.setBounds(14, 12, 184, 50);
		
		
		// Button : delete, revise
		btnDelete = new JButton("DELETE");
		btnDelete.setBounds(197, 298, 105, 27);
		btnDelete.setEnabled(false);
		
		btnRevise = new JButton("REVISE");
		btnRevise.setBounds(316, 298, 105, 27);
		btnRevise.setEnabled(false);
		

		// add List
		getContentPane().add(panel);
		panel.add(list);
		panel.add(scheduleDateLabel);
		panel.add(btnRevise);
		panel.add(btnDelete);
	}
	
	public void run()
	{
		btnDelete.addActionListener(this);
		btnRevise.addActionListener(this);
	}
	
	
	public void setClickDate(String clickYear, String clickMonth)
	{
		this.clickYear = clickYear;
		this.clickMonth = clickMonth;
	}
		
	public void removeAllList()
	{
		tempContents.clear();
	}
	
	public void removeAllElements()
	{
		model.removeAllElements();
	}
	
	public void allClear()
	{
		tempAllDate.clear();
		tempAllSchedule.clear();
		tempAllTime.clear();
	}

	public void addList(String contents, String date)
	{
		
		this.date = date;
		String time, schedule, reSaveContents;
		setVisible(true);
		
		
		String sprit[] = contents.split("  ");
		time = sprit[0];
		schedule = sprit[1];
		this.time = time;		
		reSaveContents = time + "/" + schedule;
		
		model.addElement(contents);
		scheduleDateLabel.setText(date);
		tempContents.add(reSaveContents);
	}
	
	
	public void addAllList(String date, String time, String schedule)
	{
		tempAllDate.add(date);
		tempAllTime.add(time);
		tempAllSchedule.add(schedule);

	}
	
	public void addReviseList(String inputScheule)
	{
		tempAllDate.add(index, reDate);
		tempAllTime.add(index, reTime);
		tempAllSchedule.add(index, inputScheule);
	}	
	
	 
	public void reSave(String date) 
	{
		try 
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(date + ".txt")); // 이어쓰기

			for (int i = 0; i < tempContents.size(); i++) 
			{
				bw.write(tempContents.get(i));
				bw.newLine();
			}
			bw.close();
		}

		catch (IOException e) {	}
	} // save end
	
	
	
	public void allReSave() 
	{
		try 
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter("allDate.txt")); // 이어쓰기

			for (int i = 0; i < tempAllSchedule.size(); i++) 
			{
				bw.write(tempAllDate.get(i) + "/" + tempAllTime.get(i) + "/" + tempAllSchedule.get(i) );
				bw.newLine();
			}
			bw.close();
		}

		catch (IOException e) { }
	} // save end
	
	
	public void deleteOfAllSchedule(int select)
	{
		
		for (int i = 0; i < tempAllSchedule.size(); i++)
		{
			if( (tempAllTime.get(i) + "/" + tempAllSchedule.get(i)).equals(tempContents.get(select)) )
			{
				this.index = i;

				this.reDate = tempAllDate.get(i);
				this.reTime = tempAllTime.get(i);
				this.reSchedule = tempAllSchedule.get(i);
								
				tempAllSchedule.remove(i);
				tempAllDate.remove(i);
				tempAllTime.remove(i);	
			}
		}		
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if( btnDelete == e.getSource() )
		{
			select = list.getSelectedIndex();
			model.remove(select);
			deleteOfAllSchedule(select);
			tempContents.remove(select);
			reSave(date);
			allReSave();
			
			btnDelete.setEnabled(false);
			btnRevise.setEnabled(false);
			
			if( model.size() == 0)
				cf.getfindButton(cf.getClickindex());
		}
		
		else if ( btnRevise == e.getSource() )
		{
			try
			{
				String inputScheule = JOptionPane.showInputDialog("Input revise Schedule");
			
			if( inputScheule.equals("") || inputScheule.equals(" "))
			{
				JOptionPane.showMessageDialog(null, "input Schedule!", "false", JOptionPane.ERROR_MESSAGE);
				return;
			}
                        
                        if( !inputScheule.equals(null) )
			{
				select = list.getSelectedIndex();
                              model.remove(select);
                              model.add(select, time + "  " + inputScheule);
			
                              deleteOfAllSchedule(select);
                              tempContents.remove(select);
			
                              addReviseList(inputScheule);
                              tempContents.add(select, time + "/" + inputScheule);

                              reSave(date);
                              allReSave();
			
                              btnRevise.setEnabled(false);
                              btnDelete.setEnabled(false);
			}
			
			
			
			}
			catch( NullPointerException exception ) {}
		}

	}
        
        
}