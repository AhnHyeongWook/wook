import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

public class FileManager
{

	private int index;
	private ScheduleManageFrame sf;
	private ScheduleListPanel sp = new ScheduleListPanel();
	private String clickYear, clickMonth;
	
	public FileManager( CalenderFrame cf) 
	{
		index = 0;
		sf = new ScheduleManageFrame(cf);
	}


	public void save(String inputScheule, int year, int month, int day, int hour, int minute, int second) 
	{
		String time = hour + ":" + minute + ":" + second;
		String date = year + "-" + month + "-" + day;		

		try 
		{			
			BufferedWriter bw = new BufferedWriter(new FileWriter(date + ".txt", true)); // 이어쓰기

			bw.write(time + "/" + inputScheule);
			bw.newLine();
			
			bw.close();
		} 
		
		catch (IOException e) 
		{}
	} // save end
	
	
	
	public void saveAll(String inputScheule, int year, int month, int day, int hour, int minute, int second)
	{
		String time = hour + ":" + minute + ":" + second;
		String date = year + "-" + month + "-" + day;		

		try 
		{			
			BufferedWriter bw = new BufferedWriter(new FileWriter("allDate.txt", true)); // 이어쓰기

			bw.write(date + "/" + time + "/" + inputScheule);
			bw.newLine();
			
			bw.close();
		} 
		
		catch (IOException e) 
		{	}
	}// allSave end


	public void load(String openDate) 
	{
		String time;
		String schedule;
		
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader(openDate + ".txt"));
			
			String str; // "str" is save place
			sf.removeAllElements();
			sf.removeAllList();
			
			while ((str = br.readLine()) != null ) 
			{
				String sprit[] = str.split("/");	// "/" split
				
				time = sprit[0];
				schedule = sprit[1];
				
				sf.addList(time + "  " + schedule, openDate);
			}
			br.close();
		} 
		catch (IOException e) {	} 	
	} // load end	
	
	
	
	public void loadAll() 
	{
		String date, time, schedule;
		String year, month, day;
		
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader("allDate.txt"));
			
			String str; // "str" is save place
			sf.allClear();
			while ((str = br.readLine()) != null ) 
			{
				String sprit[] = str.split("/");	// "/" split
				date = sprit[0];
				time = sprit[1];
				schedule = sprit[2];
								
				sf.addAllList(date, time, schedule);
			}
			br.close();
			
		} 
		catch (IOException e) {} 	
	} // allLoad end
	
	public void setClickDate(String clickYear, String clickMonth)
	{
		this.clickYear = clickYear;
		this.clickMonth = clickMonth;
		
		sf.setClickDate(clickYear, clickMonth);
	}
	
	
} // fileManager Class end
