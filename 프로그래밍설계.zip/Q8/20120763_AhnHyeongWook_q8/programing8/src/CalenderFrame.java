import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


class CalenderFrame extends JFrame implements ActionListener

{
	private String[] days = { "SUN", "MON", "TUS", "WEN", "TUR", "FIR", "SAT" };
	private int year, month, day, memoday = 0;
	private Font f = new Font("Sherif", Font.BOLD, 18);
	private Calendar today;
	private Calendar cal;
	private Calendar nowTime;
	private JButton btnBefore, btnAfter;
	private  JButton[] calBtn = new JButton[49];
	private JPanel panCenter;
	private JPanel panNorth;
	private JLabel lblMonthTxt, lblYearTxt;
	private JLabel lblYear;
	private JLabel lblMonth;
	private PopupMenu popupMenu;
	private MenuItem addSchedule, viewSchedule;
	private String inputScheule = "";
	private FileManager fm = new FileManager(this);
	private JButton btnChangeSchedule;
	private ScheduleListPanel sp = new ScheduleListPanel();
	private MonthScheduleListPanel mp = new MonthScheduleListPanel();
	private int changeStateAll = 0;
	private int changeStateMonth = 0;
	private JButton btnMonth;
	private int clickIndex = 0;	
	
	private JPanel panSouth;
	private JLabel lblNewLabel;


	public CalenderFrame() 
	{
		init();
		run();
		loadColorButton();
	}

	
	public void init()
	{
		
		// frame
		setTitle("My Calender");
		setBounds(100, 100, 1100, 800);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
		// Calender
		today = Calendar.getInstance(); // 디폴트의 타임 존 및 로케일을 사용해 달력을 가져옵니다.
		cal = new GregorianCalendar();
		year = today.get(Calendar.YEAR);
		month = today.get(Calendar.MONTH) + 1;// 1월의 값이 0
		
		
		// Panel : north
		panNorth = new JPanel();
		panNorth.setBackground(Color.WHITE);
		
		/** Button : before, after **/ 
		btnBefore = new JButton(" << ");
		btnBefore.setContentAreaFilled(false);
		btnBefore.setBorderPainted(false);
		
		btnAfter = new JButton(" >> ");
		btnAfter.setContentAreaFilled(false);
		btnAfter.setBorderPainted(false);
		
		btnChangeSchedule = new JButton("All Schedule List");
		btnMonth = new JButton("Month Schedule List");


		/** JLabel : month, year **/ 
		lblYearTxt = new JLabel(year + "  ");
		lblYearTxt.setHorizontalAlignment(SwingConstants.CENTER);
		lblYearTxt.setFont(new Font("Vijaya", Font.BOLD, 70));
		
		lblYear = new JLabel("YEAR   ");
		lblYear.setFont(new Font("Vijaya", Font.BOLD, 60));
		
		lblMonthTxt = new JLabel(month + "  ");
		lblMonthTxt.setHorizontalAlignment(SwingConstants.CENTER);
		lblMonthTxt.setFont(new Font("Vijaya", Font.BOLD, 70));
		
		lblMonth = new JLabel("MONTH");
		lblMonth.setFont(new Font("Vijaya", Font.BOLD, 60));
		
		
		// Panel : center
		panCenter = new JPanel(new GridLayout(7, 7));
		panCenter.setBackground(Color.WHITE);
		f = new Font("Sherif", Font.BOLD, 12);
		
		/** contents : weekInit, calSet, hideInit **/ 
		weekInit(); // add Monday ~ Sunday; 
		calSet();
		hideInit();
		
		
		//test
		CurrentClock clock = new CurrentClock();
		clock.setBounds(15, 20, 179, 149);
		new Thread(clock).start();
		
		
		// PopupMenu
		popupMenu = new PopupMenu();
		addSchedule = new MenuItem("Add Scheule");
		viewSchedule = new MenuItem("View Scheule");
				
		
		// add List
		getContentPane().add(panNorth, "North");
		getContentPane().add(panCenter, "Center");
		getContentPane().add(clock, "South");
		
		panNorth.add(btnBefore);
		panNorth.add(lblYearTxt);
		panNorth.add(lblYear);
		panNorth.add(lblMonthTxt);
		panNorth.add(lblMonth);
		panNorth.add(btnAfter);
		
		panNorth.add(btnMonth);
		panNorth.add(btnChangeSchedule);
		
		getContentPane().add(popupMenu);
		popupMenu.add(addSchedule);
		popupMenu.add(viewSchedule);
		
		setVisible(true);	
	}

	public void run()
	{
		btnBefore.addActionListener(this);
		btnAfter.addActionListener(this);
		addSchedule.addActionListener(this);
		viewSchedule.addActionListener(this);
		btnChangeSchedule.addActionListener(this);
		btnMonth.addActionListener(this);
	}	

	
	public void actionPerformed(ActionEvent e)
	{
		// Button : before
		if (e.getSource() == btnBefore) 
		{
			this.panCenter.removeAll();
			loadColorButton();
			calInput(-1);
			weekInit();
			panelInit();
			calSet();
			hideInit();
			
			
			this.lblYearTxt.setText(year + "  ");
			this.lblMonthTxt.setText(month + "  ");
			
			if( changeStateMonth % 2 != 0)
			{
				mp.loadAll(year, month);
				mp.addTable();
				mp.removeAllList();
				getContentPane().add(mp, "Center");
				mp.setVisible(true);
				panCenter.setVisible(false);
			}
			
			loadColorButton();
			
		} 
		
		
		// Button : after
		else if (e.getSource() == btnAfter) 
		{
			this.panCenter.removeAll();
			loadColorButton();
			calInput(1);
			weekInit();
			panelInit();
			calSet();
			hideInit();
			
			this.lblYearTxt.setText(year + "  ");
			this.lblMonthTxt.setText(month + "  ");
			
			if( changeStateMonth % 2 != 0)
			{
				mp.loadAll(year, month);
				mp.addTable();
				mp.removeAllList();
				getContentPane().add(mp, "Center");
				mp.setVisible(true);
				panCenter.setVisible(false);
			}
			
			loadColorButton();
		}
		
		
		
		
		
		// Button : addSchedule
		else if( addSchedule == e.getSource() )
		{
			nowTime = new GregorianCalendar();
			
			int hour = nowTime.get(Calendar.HOUR_OF_DAY); // 24시간제
			String rhour = "";
			
			if( hour < 10 )
				rhour = "0" + Integer.toString(hour);
			
			else
				rhour = Integer.toString(hour);
			
			int minute = nowTime.get(Calendar.MINUTE);
			int second =  nowTime.get(Calendar.SECOND);
                        
			try 
			{
			inputScheule = JOptionPane.showInputDialog(year + "." + month +"." + day + " / " + Integer.parseInt(rhour) + " : " + minute + " : " + second + "\n" + "Input new Schedule");
						
			if( inputScheule.equals("") || inputScheule.equals(" "))
			{
				JOptionPane.showMessageDialog(null, "input Schedule!", "false", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			
				if( !inputScheule.equals(null) )
				{
					findButton(clickIndex);
					fm.save(inputScheule, year, month, day, Integer.parseInt(rhour), minute, second);
					fm.saveAll(inputScheule, year, month, day, Integer.parseInt(rhour), minute, second);
				}
				
			} catch (Exception exception) {	}	
		}
		
		
		
		// Button : viewSchedule
		else if ( viewSchedule == e.getSource() )
		{ 
			String date = year + "-" + month + "-" + day;

			fm.load(date);
			fm.loadAll();
			fm.setClickDate(lblYearTxt.getText(), lblMonthTxt.getText());
		}
		
		
		
		// Button : ChangeMonth
		else if ( btnChangeSchedule == e.getSource() )
		{
			changeStateAll++;
			
			if( changeStateAll % 2 != 0)
			{
				sp.loadAll();
				sp.addTable();
				sp.removeAllList();
				getContentPane().add(sp, "Center");
				sp.setVisible(true);
				panCenter.setVisible(false);
				btnMonth.setEnabled(false);
				
			}
			
			else if( changeStateAll % 2 == 0)
			{
				panCenter.setVisible(true);
				sp.setVisible(false);
				btnMonth.setEnabled(true);

			}
		}
		
		
		
		else if ( btnMonth == e.getSource() )
		{
			changeStateMonth ++;
			
			if( changeStateMonth % 2 != 0)
			{
				mp.loadAll(year, month);
				mp.addTable();
				mp.removeAllList();
				getContentPane().add(mp, "Center");
				mp.setVisible(true);
				panCenter.setVisible(false);
				btnChangeSchedule.setEnabled(false);
			}
			
			else if( changeStateMonth % 2 == 0)
			{
				panCenter.setVisible(true);
				mp.setVisible(false);
				btnChangeSchedule.setEnabled(true);
			}
		}
		
	
		else if (Integer.parseInt(e.getActionCommand()) >= 1 && Integer.parseInt(e.getActionCommand()) <= 31) 
		{
			day = Integer.parseInt(e.getActionCommand());
			calSet();
		}
		
		
		for( int i = 0; i < 49; i++ )
		{
			if( calBtn[i] == e.getSource() )
			{
				clickIndex = Integer.parseInt(calBtn[i].getText());
				popupMenu.show(calBtn[i], 100, 50 );
			}
		}
		
		
	}// end Action performed method
	
	
	
	
	
	public void calSet() {
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, (month - 1));
		cal.set(Calendar.DATE, 1);
		
		int j = 0;
		int emptyPlace = 0;
		int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
		int firstDay = cal.getMinimum(Calendar.DAY_OF_MONTH);
		int endDay = cal.getMaximum(Calendar.DAY_OF_MONTH);
		
		calBtn[0].setForeground(new Color(255, 0, 0)); // Sunday Color
		calBtn[6].setForeground(new Color(0, 0, 255)); // Saturday Color
		
		for (int i = cal.getFirstDayOfWeek(); i < dayOfWeek; i++)
			j++;

		// set empty place Sunday to first day of week 
		emptyPlace = j;
		for (int i = 0; i < emptyPlace; i++)
			calBtn[i + 7].setText("");

		
		for (int i = firstDay; i <= endDay; i++)
		{
			cal.set(Calendar.DATE, i);
			
			if (cal.get(Calendar.MONTH) != month - 1)
				break;

			if (memoday == 1)
				calBtn[i + 6 + emptyPlace].setForeground(Color.GREEN);
			
			else 
			{
				calBtn[i + 6 + emptyPlace].setForeground(Color.BLACK);
				
				if ((i + emptyPlace - 1) % 7 == 0) // Sunday
					calBtn[i + 6 + emptyPlace].setForeground(Color.RED);
				
				if ((i + emptyPlace) % 7 == 0) // Saturday
					calBtn[i + 6 + emptyPlace].setForeground(Color.BLUE);
			}

			calBtn[i + 6 + emptyPlace].setText((i) + "");
		}// for end
	}// end Calset method

	

	
	public void hideInit() 
	{
		for (int i = 0; i < calBtn.length; i++) 
		{
			if ((calBtn[i].getText()).equals(""))
				calBtn[i].setEnabled(false);

		}// end for
	}// end hideInit method

	public void weekInit() {

		for (int i = 0; i < days.length; i++) 
		{
			calBtn[i] = new JButton(days[i]); 
			calBtn[i].setContentAreaFilled(false);
			calBtn[i].setBorderPainted(false);
			calBtn[i].setFont(new Font("Vijaya", Font.BOLD, 30));
			
			panCenter.add(calBtn[i]);			
		}
		
		for (int i = days.length; i < 49; i++) 
		{
			calBtn[i] = new JButton("");
			calBtn[i].addActionListener(this);
			calBtn[i].setBackground(Color.WHITE);
			panCenter.add(calBtn[i]);
		}
	}// end gridInit method

	public void panelInit() 
	{
		GridLayout gridLayout1 = new GridLayout(7, 7);
		panCenter.setLayout(gridLayout1);
	}// end panelInit method

	public void calInput(int gap) 
	{
		month += (gap);
		if (month <= 0) 
		{
			month = 12;
			year = year - 1;
		} 
		
		else if (month >= 13) 
		{
			month = 1;
			year = year + 1;
		}
	}// end calInput()


	public void findButton(String year, String month, String day)
	{
		for (int i = 0; i < calBtn.length; i++) 
		{
			if( calBtn[i].getText().equals(day) )
			{
				calBtn[i].setBackground(Color.MAGENTA);
			}
		}
	}	// end findButton
	
	
	public void findButton(int day)
	{
		for (int i = 0; i < calBtn.length; i++) 
		{
			if( calBtn[i].getText().equals(Integer.toString(day)) )
			{
				calBtn[i].setBackground(Color.MAGENTA);
			}
		}
	}	// end findButton
	
	public int getClickindex(){ return clickIndex; }
	public void getfindButton(int day)
	{
		for (int i = 0; i < calBtn.length; i++) 
		{
			if( calBtn[i].getText().equals(Integer.toString(day)) )
			{
				calBtn[i].setBackground(Color.WHITE);
			}
		}
	}	// end findButton
	

	public void loadColorButton() 
	{
		String date, time, schedule;
		String year, month, day;
		
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader("allDate.txt"));
			
			String str; // "str" is save place
			
			while ((str = br.readLine()) != null ) 
			{
				String sprit[] = str.split("/");	// "/" split
				date = sprit[0];
				time = sprit[1];
				schedule = sprit[2];
				
				String sprit2[] = date.split("-");
				year = sprit2[0] + "  ";
				month = sprit2[1] + "  ";
				day = sprit2[2];
				
				if( year.equals(lblYearTxt.getText()) && month.equals(lblMonthTxt.getText()))
				{
					findButton(year, month, day);
				}	
			}
			br.close();
			
		} 
		catch (IOException e) {	} 	
	} // allLoad end 

	public static void main(String[] args) {
		CalenderFrame jdbc = new CalenderFrame();

	}// end class
}

