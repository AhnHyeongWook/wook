import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JTextField;

import java.awt.Component;
import java.awt.ComponentOrientation;

import javax.swing.JLabel;


public class ScheduleListPanel extends JPanel {
	private ArrayList<String> tempAllDate = new ArrayList<String>();
	private ArrayList<String> tempAllTime = new ArrayList<String>();
	private ArrayList<String> tempAllSchedule = new ArrayList<String>();
	
	private JScrollPane tableScrollPane;
	private JTable jtbSchedule;
	private String colName[] = {"DATE","SCHEDULE"};
	private DefaultTableModel model = new DefaultTableModel(colName, 0);
	private JTextField txtZzsz;
	private JLabel lblHints;
	private JLabel lblScheduleList;

	
	public ScheduleListPanel() {
		setBackground(Color.WHITE);
		init();
		run();
		

	}
	
	public void init()
	{
		setLayout(null);

		// wordTable
		jtbSchedule = new JTable(model);
		jtbSchedule.setFont(new Font("맑은고딕", Font.PLAIN, 15));
		jtbSchedule.getColumn("DATE").setPreferredWidth(150);
		jtbSchedule.getColumn("SCHEDULE").setPreferredWidth(200);
		jtbSchedule.setRowHeight(30);
		jtbSchedule.setAutoCreateRowSorter(true);
		TableRowSorter sorter = new TableRowSorter(jtbSchedule.getModel());
		jtbSchedule.setRowSorter(sorter);
		
		tableScrollPane = new JScrollPane();
		tableScrollPane.setBounds(90, 90, 922, 512);
		tableScrollPane.setViewportView(jtbSchedule);		
		
		// table CENTER sort
		DefaultTableCellRenderer tScheduleCellRenderer = new DefaultTableCellRenderer();
		tScheduleCellRenderer.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tcmSchedule = jtbSchedule.getColumnModel();
		for (int i = 0; i < tcmSchedule.getColumnCount(); i++) 
			tcmSchedule.getColumn(i).setCellRenderer(tScheduleCellRenderer);
		
		
		// Label
		lblScheduleList = new JLabel("ALL SCHEDULE LIST");
		lblScheduleList.setForeground(Color.RED);
		lblScheduleList.setFont(new Font("Vijaya", Font.PLAIN, 50));
		lblScheduleList.setBounds(614, 12, 398, 54);
		
		lblHints = new JLabel("Clicked by DATE header, this row's are sorted ascending order");
		lblHints.setFont(new Font("굴림", Font.PLAIN, 15));
		lblHints.setBounds(586, 605, 426, 18);
		
		
		// add List
		add(tableScrollPane);
		add(lblScheduleList);
		add(lblHints);
		
		
	}
	
	
	public void run()
	{
		
		
	}
	
	public void addAllList(String date, String time, String schedule)
	{		
		tempAllDate.add(date + "  " + time);
		tempAllSchedule.add(schedule);
	}
	
	public void removeAllList()
	{
		tempAllDate.clear();
		tempAllSchedule.clear();
	}
	
	public void addTable()
	{		
		DefaultTableModel model = (DefaultTableModel) jtbSchedule.getModel();
		model.setNumRows(0);
	
		for( int i = 0; i < tempAllSchedule.size(); i++)
		{
			String arr[] = new String[2];
			arr[0] = tempAllDate.get(i);
			arr[1] = tempAllSchedule.get(i);
			
			model.addRow(arr);
		}
	}
	
	public void loadAll() 
	{
		String date, time, schedule;
		String year, month, day;
		
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader("allDate.txt"));
			
			String str; // "str" is save place
			
			while ((str = br.readLine()) != null ) 
			{
				String sprit[] = str.split("/");	// "/" split
				date = sprit[0];
				time = sprit[1];
				schedule = sprit[2];
				
				String sprit2[] = date.split("-");
				 year = sprit2[0];
				 month = sprit2[1];
				 day = sprit2[2];
				 
				 if( Integer.parseInt(month) < 10)
				 {
					 date = year + "-0" + month + "-" + day; 
				 }
								
				addAllList(date, time, schedule);
			}
			br.close();
			
		} 
		catch (IOException e) {} 	
	} // allLoad end
}
