import javax.swing.JFrame;

public class MainFrame extends JFrame
{

	private MainPanel mainPanel;

	public MainFrame() {
		init();
	}
	
	public void init()
	{
		// Frame option
		setTitle("PIZZA HUT");
		setBounds(300, 50, 1271, 800);
		getContentPane().setLayout(null);
		
		// Panel
		mainPanel = new MainPanel();
		mainPanel.setBounds(0, 0, 1318, 753);
	
		// addList
		getContentPane().add(mainPanel);
	
	} // init method end
	
	public static void main(String[] args) 
	{
		MainFrame frame = new MainFrame();
		frame.setVisible(true);
	}
} // Converter class end