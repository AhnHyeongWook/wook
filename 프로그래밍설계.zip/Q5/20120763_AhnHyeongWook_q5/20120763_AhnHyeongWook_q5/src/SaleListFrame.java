import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;

public class SaleListFrame extends JFrame 
{

	private JPanel panel;
	private PizzaList pizza = new PizzaList();
	private JScrollPane scrollPane;
	private String colName[] = { "PIZZA", "QTY", "TOTAL($)" };
	private DefaultTableModel model = new DefaultTableModel(colName, 0);
	private JTable basketTable = new JTable(model);
	private JLabel saleList;
	private PizzahutLogoPanel logo;

	public SaleListFrame() 
	{
		init();
	}

	public void init() 
	{
		// frame
		setTitle("SALE LIST");
		setBounds(600, 300, 386, 289);
		setVisible(true);
		
		
		// panel
		panel = new JPanel();
		panel.setBounds(0, 0, 368, 395);
		panel.setBackground(Color.BLACK);
		panel.setLayout(null);
		getContentPane().setLayout(null);
		
		
		// pizza hut logo
		logo = new PizzahutLogoPanel();
		logo.setBounds(14, 12, 101, 59);
		
		
		// Label : Order state
		saleList = new JLabel("SALE LIST");
		saleList.setFont(new Font("Vijaya", Font.PLAIN, 48));
		saleList.setForeground(Color.WHITE);
		saleList.setBounds(139, 12, 194, 59);
		
		
		// table
		basketTable.setFont(new Font("Vijaya", Font.PLAIN, 25));
		basketTable.getColumn("PIZZA").setPreferredWidth(200);
		basketTable.setRowHeight(30);
		scrollPane = new JScrollPane();
		scrollPane.setBounds(14, 83, 340, 143);
		panel.add(scrollPane);
		scrollPane.setViewportView(basketTable);
		
		
		//add list
		getContentPane().add(panel);
		panel.add(saleList);
		panel.add(logo);
	}

	public void setPizza(PizzaList pizza) 
	{
		this.pizza = pizza;
	}

	public void setTable() 
	{
		for (int i = 0; i < 4; ++i) 
		{
			String toping = pizza.getIndexToping(i);
			int quantity = pizza.getIndexQuantity(i);
			int total_price = (pizza.getIndexPrice(i) * pizza.getIndexQuantity(i));
			
			model.insertRow(model.getRowCount(),new Object[] { toping, quantity, total_price });
		}
	}
}
