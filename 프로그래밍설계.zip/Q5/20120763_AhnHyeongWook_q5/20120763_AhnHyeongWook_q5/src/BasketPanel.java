import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JPanel;

public class BasketPanel extends JPanel {

	private Image basket;

	public BasketPanel()
	{
		setBounds(0, 0, 200, 200);
		setOpaque(false);

		basket = Toolkit.getDefaultToolkit().createImage("image/basket_1.png");
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);

		g.drawImage(basket, 0, 0, this);
	}
}
