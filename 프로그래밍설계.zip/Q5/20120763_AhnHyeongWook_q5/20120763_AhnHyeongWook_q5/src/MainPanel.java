import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class MainPanel extends JPanel implements ActionListener{

	private PizzaList pizza = new PizzaList();
	private PizzahutLogoPanel logo;
	private NumberBoardPanel np;
	private MenuPanel mp;
	private BasketPanel bp;
	private SaleListFrame sf;
	
	private JButton saleListButton;
	private JButton clearButton;
	private JLabel kindLabel;
	private JLabel quantityLabel;
	private JLabel orderStateLabel;
	private JTextField pizzaTextField;
	private JTextField quantityTextField;
	private JButton orderButton;
	private JButton okButton;
	private JButton deleteListButton;
	private String sumText = "";
	private JTable basketTable;
	private JScrollPane scrollPane;
	private String colName[] = {"PIZZA","QTY","PRICE($)"};
	private DefaultTableModel model = new DefaultTableModel(colName, 0);

	public MainPanel() {
		init();
		run();
	}

	public void init() 
	{
		setBackground(Color.BLACK);
		setBounds(0, 0, 1302, 753);
		setLayout(null);

		
		// pizza hut logo
		logo = new PizzahutLogoPanel();
		logo.setBounds(39, 37, 101, 59);
		
		
		// basket panel
		bp = new BasketPanel();
		bp.setBounds(1085, 180, 143, 112);

		
		// menu Panel
		mp = new MenuPanel();
		mp.setBounds(75, 117, 700, 499);

		
		// numberBoard Panel
		np = new NumberBoardPanel();
		np.setBounds(75, 652, 668, 59);
		
			
		// Button : saleList
		saleListButton = new JButton(new ImageIcon("image/bt_navi_3.png"));
		saleListButton.setToolTipText("saleListButton");
		saleListButton.setBounds(729, 644, 75, 67);
		saleListButton.setBorderPainted(false);
		saleListButton.setFocusPainted(false);
		saleListButton.setContentAreaFilled(false);
		
		
		// Button : order
		orderButton = new JButton("ORDER");
		orderButton.setFont(new Font("Vijaya", Font.PLAIN, 18));
		orderButton.setEnabled(false);
		orderButton.setBounds(881, 538, 88, 27);
		

		// Button : ok
		okButton = new JButton("OK");
		okButton.setFont(new Font("Vijaya", Font.PLAIN, 17));
		okButton.setEnabled(false);
		okButton.setBounds(811, 538, 53, 27);
		
		
		// Button : clear
		clearButton = new JButton("CLEAR");
		clearButton.setFont(new Font("Vijaya", Font.PLAIN, 19));
		clearButton.setBounds(988, 538, 88, 27);
		
		
		// Button : delete
		deleteListButton = new JButton("DELETE");
		deleteListButton.setFont(new Font("Vijaya", Font.PLAIN, 19));
		deleteListButton.setBounds(1090, 538, 105, 27);
	
		
		// Label : Pizza
		kindLabel = new JLabel("Pizza :");
		kindLabel.setFont(new Font("Vijaya", Font.PLAIN, 30));
		kindLabel.setForeground(Color.WHITE);
		kindLabel.setBounds(154, 28, 75, 32);

		
		// Label : Quantity
		quantityLabel = new JLabel("Quantity : ");
		quantityLabel.setForeground(Color.WHITE);
		quantityLabel.setFont(new Font("Vijaya", Font.PLAIN, 30));
		quantityLabel.setBounds(150, 68, 116, 28);
		
		
		// Label : Order state
		orderStateLabel = new JLabel("ORDER STATE");
		orderStateLabel.setFont(new Font("Vijaya", Font.PLAIN, 48));
		orderStateLabel.setForeground(Color.WHITE);
		orderStateLabel.setBounds(809, 203, 249, 59);

		
		// TextField : pizzaList
		pizzaTextField = new JTextField();
		pizzaTextField.setFont(new Font("Vijaya", Font.PLAIN, 25));
		pizzaTextField.setForeground(Color.WHITE);
		pizzaTextField.setBounds(229, 30, 206, 32);
		pizzaTextField.setEditable(false);
		pizzaTextField.setOpaque(false);
		pizzaTextField.setBorder(javax.swing.BorderFactory.createEmptyBorder());


		// TextField : pizza quantity
		quantityTextField = new JTextField();
		quantityTextField.setFont(new Font("Vijaya", Font.PLAIN, 25));
		quantityTextField.setForeground(Color.WHITE);
		quantityTextField.setBounds(253, 68, 116, 32);
		quantityTextField.setEditable(false);
		quantityTextField.setOpaque(false);
		quantityTextField.setBorder(javax.swing.BorderFactory.createEmptyBorder());
		
		
		// table : basket
		basketTable = new JTable(model);
		basketTable.setFont(new Font("Vijaya", Font.PLAIN, 25));
		basketTable.getColumn("PIZZA").setPreferredWidth(200);
		basketTable.setRowHeight(30);
		scrollPane = new JScrollPane();
		scrollPane.setBounds(811, 280, 384, 246);
		scrollPane.setViewportView(basketTable);
		
		
		// addList
		/** panels **/
		add(np);
		add(mp);
		add(bp);
		add(logo);
		
		/** labels **/
		add(quantityLabel);
		add(kindLabel);
		add(orderStateLabel);
		
		/** buttons **/
		add(saleListButton);
		add(deleteListButton);
		add(okButton);
		add(clearButton);
		add(orderButton);
		
		/** textFields **/
		add(quantityTextField);
		add(pizzaTextField);
		
		/** table **/
		add(scrollPane);	
	} // init method end
	
	
	// action start
	public void run()
	{
		for (int i = 0; i < 4; i++) 
			mp.getPizzaList(i).addActionListener(this);
		
		for (int i = 0; i < 11; i++) 
			np.getNumberButton(i).addActionListener(this);
		
		orderButton.addActionListener(this);
		okButton.addActionListener(this);
		clearButton.addActionListener(this);
		saleListButton.addActionListener(this);
		deleteListButton.addActionListener(this);
	}
	
	public void allClear()
	{
		sumText = "";
		okButton.setEnabled(false);
		orderButton.setEnabled(false);
		pizzaTextField.setText(null);
		quantityTextField.setText(null);
	
		DefaultTableModel model = (DefaultTableModel) basketTable.getModel();
		model.setNumRows(0);
	}


	// action process
	public void actionPerformed(ActionEvent e) 
	{
		// pizzaButton action
		for (int i = 0; i < 4; i++) 
		{
			if( mp.getPizzaList(i) == e.getSource() )
			{
				if( !quantityTextField.getText().equals(""))
					okButton.setEnabled(true);
				
				switch (i) 
				{
				case 0:
					pizzaTextField.setText(pizza.getIndexToping(0));
					break;
				case 1:
					pizzaTextField.setText(pizza.getIndexToping(1));
					break;
				case 2:
					pizzaTextField.setText(pizza.getIndexToping(2));
					break;
				case 3:
					pizzaTextField.setText(pizza.getIndexToping(3));
					break;
				default:
					break;
				}
			} // if end
		} // for end
		
		
		// okButton action
		if( okButton == e.getSource() )
		{			
			// 같은메뉴 잇으면 클릭햇을때 오류나게 해야댐 ㅠ
			for (int i = 0; i < basketTable.getRowCount(); i++) 
			{
				String toping = (String) basketTable.getValueAt(i, 0);
				
				if( toping.equals(pizzaTextField.getText()))
				{
					JOptionPane.showMessageDialog(null, "pizza is already exist", "false", JOptionPane.ERROR_MESSAGE);
					return;
				}
			}
			
			// establish max quantity
			if( quantityTextField.getText().length() > 2 )
			{
				JOptionPane.showMessageDialog(null, "quantity should not exceed 100", "false", JOptionPane.ERROR_MESSAGE);
			}
			
			else if( quantityTextField.getText().equals("0"))
			{
				JOptionPane.showMessageDialog(null, "quantity should not 0", "false", JOptionPane.ERROR_MESSAGE);
			}
				
			else
			{
				String arr[] = new String[3];
				arr[0] = pizzaTextField.getText();
				arr[1] = quantityTextField.getText();
				arr[2] = ( Integer.toString(pizza.getPizzaPrice(arr[0]) * Integer.parseInt(arr[1])) );
				DefaultTableModel model = (DefaultTableModel) basketTable.getModel();
				model.addRow(arr);
				
				okButton.setEnabled(false);
				pizzaTextField.setText("");
				quantityTextField.setText("");
				sumText = "";
				orderButton.setEnabled(true);
			}	
		} // okButton action end
		
		
		// orderButton action
		if( orderButton == e.getSource() )
		{
			JOptionPane.showMessageDialog(null, "order Success", "Success", JOptionPane.INFORMATION_MESSAGE);
			
			for (int i = 0; i < basketTable.getRowCount(); i++) 
			{
				String toping = (String) basketTable.getValueAt(i, 0);
				int quantity = Integer.parseInt((String) basketTable.getValueAt(i, 1));
				int price = Integer.parseInt((String)basketTable.getValueAt(i, 2));
				
				pizza.setPizza( toping, quantity );
			}
			allClear();
		}
		

		// numberButton action
		for (int i = 0; i < 10; i++) 
		{
			if( np.getNumberButton(i) == e.getSource() )
			{
				sumText = sumText + np.getNumberButton(i).getText();
				quantityTextField.setText(sumText);
				
				if( !pizzaTextField.getText().equals(""))
					okButton.setEnabled(true);
			}	
		} // numberButton action end
		
		
		// " ← " button action
		if( quantityTextField.getText().length() == 1 )
		{
			if( np.getNumberButton(10) == e.getSource() )
			{
				sumText = "";
				okButton.setEnabled(false);
				orderButton.setEnabled(false);
				quantityTextField.setText(null);	
			}
		}	
		
		else if( np.getNumberButton(10) == e.getSource() )
		{
			if( quantityTextField.getText().equals(""))
			{
				okButton.setEnabled(false);
				orderButton.setEnabled(false);
			}
							
			else
			{
				sumText = sumText.substring(0,sumText.length()-1);
				quantityTextField.setText(sumText);						
			}			
		} // " ← " button action end
		
		
		// deleteButton action
		if( deleteListButton == e.getSource())
		{
			int row = basketTable.getSelectedRow();
			  if ( row == -1)
			   return;
			  
			  DefaultTableModel model = (DefaultTableModel) basketTable.getModel();
			  model.removeRow(row);
			  
			  if(model.getRowCount() == 0)
			  {
				  okButton.setEnabled(false);
				  orderButton.setEnabled(false);
			  }	  
		} // deleteButton action end
		
		
		// clearButton action
		if( clearButton == e.getSource() )
		{
			allClear();
		} // clearButton action end	

		
		// saleListButton action
		if( saleListButton == e.getSource() )
		{
			sf = new SaleListFrame();
			sf.setPizza(pizza);
			sf.setTable();
		} // saleListButton action end
	} // actionPerformed method end
} // MainPanel class end