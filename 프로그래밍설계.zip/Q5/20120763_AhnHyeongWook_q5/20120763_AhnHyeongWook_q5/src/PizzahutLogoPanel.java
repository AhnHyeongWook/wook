import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JPanel;


public class PizzahutLogoPanel extends JPanel {

	private Image pizzahut;
	
	public PizzahutLogoPanel() 
	{
		setLogo();
	}
	
	public void setLogo()
	{
		pizzahut = Toolkit.getDefaultToolkit().createImage("image/pizzaHut.png");
		setBounds(0, 0, 99, 99);
		setOpaque(false);
	}

	@Override
	public void paint(Graphics g) 
	{
		super.paint(g);
		g.drawImage(pizzahut, 0, 0, this);
	}

}
