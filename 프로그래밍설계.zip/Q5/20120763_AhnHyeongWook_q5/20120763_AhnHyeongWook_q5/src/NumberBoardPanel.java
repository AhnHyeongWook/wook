import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JPanel;

import java.awt.Font;


public class NumberBoardPanel extends JPanel 
{

	private int xPos = 0;
	private JButton[] numberButtons = new JButton[11];
	
	public NumberBoardPanel() 
	{
		init();
	}

	private void init()
	{
		setOpaque(false);
		setLayout(null);
		
		
		// number button
		for(int i = 0; i < 10; i++) 
		{
			numberButtons[i] = new JButton(Integer.toString(i));
			numberButtons[i].setBounds(xPos, 0, 50, 50);
			numberButtons[i].setContentAreaFilled(false); // transparency
			numberButtons[i].setForeground(Color.WHITE); // Foreground Color
			numberButtons[i].setFont(new Font("맑은고딕", Font.PLAIN, 20));
			xPos += 60;

			add(numberButtons[i]);
		} 
		
		// "←" button
		numberButtons[10] = new JButton("←");
		numberButtons[10].setBounds(xPos, 0, 53, 50);
		numberButtons[10].setContentAreaFilled(false); // transparency
		numberButtons[10].setForeground(Color.WHITE); // Foreground Color
		numberButtons[10].setFont(new Font("맑은고딕", Font.PLAIN, 20));
		
		add(numberButtons[10]);
	
	} // init method end
	
	public JButton getNumberButton(int index){ return numberButtons[index]; }
} // NumberBoardPanel class end
