import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class MenuPanel extends JPanel
{
	private int xPos, yPos;
	private JButton pizzaList[] = new JButton[4];

	public MenuPanel() 
	{
		init();
		run();
	}


	private void init() 
	{
		// basicList
		setLayout(null);
		setOpaque(false);
		
		
		// init Buttons
		pizzaList[0] = new JButton(new ImageIcon("image/beycunPoteto.jpg"));
		pizzaList[0].setToolTipText("BaconPotato / 16$");
		pizzaList[1] = new JButton(new ImageIcon("image/bulgogi.jpg"));
		pizzaList[1].setToolTipText("Bulgogi / 18$");
		pizzaList[2] = new JButton(new ImageIcon("image/doubleBabekue.jpg"));
		pizzaList[2].setToolTipText("DoubleBarbecue / 21$");
		pizzaList[3] = new JButton(new ImageIcon("image/superSpream.jpg"));
		pizzaList[3].setToolTipText("SuperSpream / 15$");
		
		for ( int i = 0; i < pizzaList.length; i++ )
		{
			if ( i % 2 == 0 && i != 0)
			{
				xPos = 0;
				yPos += 250;
			}
			pizzaList[i].setBounds(xPos, yPos, 350, 250);
			pizzaList[i].setBorderPainted(false);
			pizzaList[i].setFocusPainted(false);
			pizzaList[i].setContentAreaFilled(false);
			
			xPos += 350;
			add(pizzaList[i]);
		}

	} // init method end
	
	
	// geter
	public JButton getPizzaList(int index) { return pizzaList[index]; }

	// action start
	public void run() {	mouseAction(); }
	
	
	// process mouse action
	public void mouseAction()
	{
		// baconPotatoPizza mouseAction
		pizzaList[0].addMouseListener(new MouseListener() 
		{
			public void mousePressed(MouseEvent e) {}
			public void mouseExited(MouseEvent e) { pizzaList[0].setBorderPainted(false); }
			public void mouseEntered(MouseEvent e) { pizzaList[0].setBorderPainted(true); }
			public void mouseClicked(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});
		
		// bulgogiPizza mouseAction
		pizzaList[1].addMouseListener(new MouseListener() 
		{
			public void mousePressed(MouseEvent e) {}
			public void mouseExited(MouseEvent e) { pizzaList[1].setBorderPainted(false); }
			public void mouseEntered(MouseEvent e) { pizzaList[1].setBorderPainted(true);}
			public void mouseClicked(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});
		
		// doubleBarbecuePizza mouseAction
		pizzaList[2].addMouseListener(new MouseListener() 
		{
			public void mousePressed(MouseEvent e) {}
			public void mouseExited(MouseEvent e) { pizzaList[2].setBorderPainted(false); }
			public void mouseEntered(MouseEvent e) { pizzaList[2].setBorderPainted(true);}
			public void mouseClicked(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});
		
		// superSpreamPizza mouseAction
		pizzaList[3].addMouseListener(new MouseListener() 
		{
			public void mousePressed(MouseEvent e) {}
			public void mouseExited(MouseEvent e) {  pizzaList[3].setBorderPainted(false);}
			public void mouseEntered(MouseEvent e) { pizzaList[3].setBorderPainted(true);}
			public void mouseClicked(MouseEvent e) {}
			public void mouseReleased(MouseEvent e) {}
		});
	} // mouseAction method end
} // MenuPanel class end
