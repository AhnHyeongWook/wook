public class Pizza 
{

	private String toping;
	private int quantity;
	private int price;
	
	public Pizza(String toping, int quantity, int price, int total_price) 
	{
		this.toping = toping;
		this.quantity = quantity;
		this.price = price;
	}
	
	public void setToping(String toping){ this.toping = toping; }
	public void setQuantity(int quantity){ this.quantity = quantity; }
	public void setPrice(int price){ this.price = price; }

	public String getToping() { return toping; }
	public int getPrice() { return price; }
	public int getQuantity() { return quantity; }
}



class PizzaList
{
	private Pizza[] pizzaList = new Pizza[4];
	
	public PizzaList()
	{
		pizzaList[0] = new Pizza("BaconPotato Pizza", 0, 16, 0);
		pizzaList[1] = new Pizza("Bulgogi Pizza", 0, 18, 0);
		pizzaList[2] = new Pizza("DoubleBarbecue Pizza", 0, 21, 0);
		pizzaList[3] = new Pizza("SuperSpream Pizza", 0, 15, 0);	
	}

	public void setPizza( String toping, int quantity )
	{
		if( toping.equals("BaconPotato Pizza"))
			pizzaList[0].setQuantity(pizzaList[0].getQuantity() + quantity);
		
		else if( toping.equals("Bulgogi Pizza"))
			pizzaList[1].setQuantity(pizzaList[1].getQuantity() + quantity);
		
		else if( toping.equals("DoubleBarbecue Pizza"))
			pizzaList[2].setQuantity(pizzaList[2].getQuantity() + quantity);
		
		else if( toping.equals("SuperSpream Pizza"))
			pizzaList[3].setQuantity(pizzaList[3].getQuantity() + quantity);
	}
	
	public String getIndexToping(int index) { return pizzaList[index].getToping(); }
	public int getIndexPrice(int index) { return pizzaList[index].getPrice(); }
	public int getIndexQuantity(int index) { return pizzaList[index].getQuantity(); }
	public int getPizzaListLength(){ return pizzaList.length; }
	
	public int getPizzaPrice(String toping) // serch Pizza price as toping name
	{
		switch (toping) 
		{
		case "BaconPotato Pizza":
			return 16;
		case "Bulgogi Pizza":
			return 18;
		case "DoubleBarbecue Pizza":
			return 21;
		case "SuperSpream Pizza":
			return 15;
		default:
			break;
		}
		return 0;
	}
}