import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

public class fileManager {

	private PizzaList pizza = new PizzaList();
	private int index;

	public fileManager() 
	{
		index = 0;
	}
	
	public void setPizza(PizzaList pizza)
	{
		this.pizza = pizza;
	}

	public void save(String fileName) 
	{
		try 
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(fileName + "List.txt"));
			
			
			for (int i = 0; i < 4; ++i) 
			{
				String toping = pizza.getIndexToping(i);
				int quantity = pizza.getIndexQuantity(i);
				int total_price = (pizza.getIndexPrice(i) * pizza.getIndexQuantity(i));
				
				bw.write(toping + "," + quantity + "," + total_price);
				bw.newLine();
			}
			
			bw.close();
		} 
		
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	} // save end


	public void load(String fileName) 
	{
		try 
		{
			String readToping;
			int readQuantity;
			int readTotalPrice;
			int readPrice;
			BufferedReader br = new BufferedReader(new FileReader(fileName));
			
			String str; // "str" is save place
			
			while ((str = br.readLine()) != null ) 
			{
				String sprit[] = str.split(",");	// "," split
				
				readToping = sprit[0];
				readQuantity = Integer.valueOf(sprit[1]);
				readTotalPrice = Integer.valueOf(sprit[2]);
				
				if( readTotalPrice == 0 && readQuantity == 0)
					readPrice = 0;
				
				else
					readPrice = readTotalPrice / readQuantity;
				
				pizza.setIndexToping(readToping, index);
				pizza.setIndexQuantity(readQuantity, index);
				pizza.setIndexPrice((readPrice), index);
				
				index ++;

			}
			br.close();
			JOptionPane.showMessageDialog(null, "load saleList file - " + fileName, "load saleList", JOptionPane.INFORMATION_MESSAGE);
		} 
		

		catch (Exception e) 
		{
			JOptionPane.showMessageDialog(null, "make new saleList file - " + fileName, "new saleList", JOptionPane.INFORMATION_MESSAGE);
		} 	
	} // load end
} // fileManager Class end
