import javax.swing.JFrame;

public class MainFrame extends JFrame
{

	private MainPanel mainPanel;
	private String year, month, day;
	private PizzaList pizza;

	public MainFrame(String year, String month, String day, PizzaList pizza) {
		
		this.year = year;
		this.month = month;
		this.day = day;
		this.pizza = pizza;
		
		init();
		setVisible(true);
	}
	
	public void init()
	{
		// Frame option
		setTitle("PIZZA HUT");
		setBounds(300, 50, 1271, 800);
		getContentPane().setLayout(null);
		
		// Panel
		mainPanel = new MainPanel(year, month, day, pizza);
		mainPanel.setBounds(0, 0, 1318, 753);
	
		// addList
		getContentPane().add(mainPanel);
	
	} // init method end
} // Converter class end