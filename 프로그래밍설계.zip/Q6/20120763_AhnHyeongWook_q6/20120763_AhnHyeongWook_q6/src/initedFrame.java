import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class initedFrame extends JFrame implements ActionListener{
	private JPanel panel;
	private PizzahutLogoPanel logo;
	private NumberBoardPanel np;
	private JButton okButton;
	private JTextField yearField;
	private JTextField monthField;
	private JTextField dayField;
	private JLabel yearLabel;
	private JLabel monthLabel;
	private JLabel dayLabel;
	private String year, month, day;
	private fileManager fm;
	private PizzaList pizza = new PizzaList();
	private String yearSumText = "";
	private String monthSumText = "";
	private String daySumText = "";
	private int selectNum = 0;

	public static void main(String[] args) {

		initedFrame frame = new initedFrame();
		frame.setVisible(true);

	}

	public initedFrame() {
		init();
		run();	
	}

	public void init() {

		// frame
		setBounds(600, 300, 855, 311);
		getContentPane().setLayout(null);
		

		// panel
		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setLocation(0, 0);
		panel.setSize(836, 273);
		panel.setLayout(null);
		
		
		// pizza hut logo
		logo = new PizzahutLogoPanel();
		logo.setBounds(710, 31, 101, 59);
		
		
		// numberBoard Panel
		np = new NumberBoardPanel();
		np.setBounds(45, 178, 668, 59);

		
		// label : today date
		JLabel todayDateLabel = new JLabel("Today Date");
		todayDateLabel.setForeground(Color.WHITE);
		todayDateLabel.setFont(new Font("Vijaya", Font.PLAIN, 70));
		todayDateLabel.setBounds(45, 31, 376, 68);

		
		// label : year, month, day
		yearLabel = new JLabel("년");
		yearLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 40));
		yearLabel.setForeground(Color.WHITE);
		yearLabel.setBounds(229, 111, 72, 55);

		
		monthLabel = new JLabel("월");
		monthLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 40));
		monthLabel.setForeground(Color.WHITE);
		monthLabel.setBounds(421, 116, 51, 50);

		dayLabel = new JLabel("일");
		dayLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 40));
		dayLabel.setForeground(Color.WHITE);
		dayLabel.setBounds(589, 116, 51, 50);

		
		// TextField : year
		yearField = new JTextField();
		yearField.setHorizontalAlignment(SwingConstants.RIGHT);
		yearField.setFont(new Font("맑은 고딕", Font.PLAIN, 40));
		yearField.setEditable(false);
		yearField.setOpaque(false);
		yearField.setForeground(Color.WHITE);
		yearField.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				yearField.selectAll();
				selectNum = 1;
			}
		});
		yearField.setBounds(126, 120, 106, 46);
		yearField.setColumns(10);

		
		// TextField : month
		monthField = new JTextField();
		monthField.setHorizontalAlignment(SwingConstants.RIGHT);
		monthField.setFont(new Font("맑은 고딕", Font.PLAIN, 40));
		monthField.setForeground(Color.WHITE);
		monthField.setOpaque(false);
		monthField.setEditable(false);
		monthField.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				monthField.selectAll();
				selectNum = 2;
			}
		});
		monthField.setBounds(349, 120, 72, 46);
		monthField.setColumns(10);

		
		// TextField : day
		dayField = new JTextField();
		dayField.setHorizontalAlignment(SwingConstants.RIGHT);
		dayField.setFont(new Font("맑은 고딕", Font.PLAIN, 40));
		dayField.setForeground(Color.WHITE);
		dayField.setOpaque(false);
		dayField.setEditable(false);
		dayField.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				dayField.selectAll();
				selectNum = 3;
			}
		});
		dayField.setBounds(516, 120, 72, 46);
		dayField.setColumns(10);

		
		// Button : ok
		okButton = new JButton("OK");
		okButton.setFont(new Font("Vijaya", Font.PLAIN, 30));
		okButton.setBounds(725, 189, 86, 34);

		
		// addList
		getContentPane().add(panel);
		panel.add(logo);
		panel.add(np);
		panel.add(todayDateLabel);
		panel.add(yearField);
		panel.add(monthField);
		panel.add(dayField);
		panel.add(okButton);
		panel.add(yearLabel);
		panel.add(dayLabel);
		panel.add(monthLabel);
	} // init end
	
	public void showMainFrame(initedFrame inf)
	{
		year = yearField.getText();
		month = monthField.getText();
		day = dayField.getText();
		
		new MainFrame(year, month, day, pizza);
		inf.dispose();
	}
	
	public String getYear() { return year; }
	public String getMonth() { return month; }
	public String getDay() { return day; }

	
	// action start
	public void run()
	{
		okButton.addActionListener(this);
		for (int i = 0 ; i < 11 ; i++) 
			np.getNumberButton(i).addActionListener(this);
	}
	

	// action process
	public void actionPerformed(ActionEvent e) {
		
		// numberButton action
		for (int i = 0; i < 10; i++) 
		{
			if (np.getNumberButton(i) == e.getSource()) 
			{
				if( yearField.getText().length() == 4 && monthField.getText().length() == 2 )
				{
					if(dayField.getText().length() == 2 )
						return;
					
					dayField.requestFocusInWindow();
					daySumText = daySumText + np.getNumberButton(i).getText();
					dayField.setText(daySumText);
				}
				
				else if( yearField.getText().length() == 4 )
				{
					monthField.requestFocusInWindow();
					monthSumText = monthSumText + np.getNumberButton(i).getText();
					monthField.setText(monthSumText);
				}
				
				else
				{
					yearSumText = yearSumText + np.getNumberButton(i).getText();
					yearField.setText(yearSumText);
				}
				

			}
		} // numberButton action end

		
		// " ← " button action
		if (np.getNumberButton(10) == e.getSource()) 
		{
			switch (selectNum) {
			case 1:
				yearField.setText("");
				yearSumText = "";
				break;				
			case 2:
				monthField.setText("");
				monthSumText = "";
				break;			
			case 3:
				dayField.setText("");
				daySumText = "";
				break;
			default:
				break;
			}
		} // if end
		

		if( okButton == e.getSource() )
		{
			year = yearField.getText();
			month = monthField.getText();
			day = dayField.getText();

			if( year.length() != 4 || month.length() != 2 || day.length() != 2 )
			{
				JOptionPane.showMessageDialog(null, "input ex) 2015-03-01 ", "false", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			else if( Integer.parseInt(month) > 12 || Integer.parseInt(month) < 1 || Integer.parseInt(day) > 31 || Integer.parseInt(day) < 1)
			{
				JOptionPane.showMessageDialog(null, " execced Month or Day number scale ", "false", JOptionPane.ERROR_MESSAGE);
				return;
			}

			fm = new fileManager();
			fm.setPizza(pizza);
			fm.load(year + month + day + "List.txt");
			showMainFrame(this);
		}
	} // actionPerformed method end
} // initedFrame class end
